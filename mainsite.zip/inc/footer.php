    <div class="container">
      <footer>
        <p class="pull-right"><a href="#">Voltar ao início</a></p>
        <p>&copy; 2014 The Grove Academia de Idiomas</p>
        <p id="footer-address">Rua Emilio Blum, 131, Loja 19 - (48)3222-2004 - contato@thegrove.com.br</p>
      </footer>
    </div>

    <!-- JavaScript
    ================================================== -->
            
    <script type="text/javascript">
      Skype.ui({
        "name": "chat",
        "element": "SkypeButton_Call_recep.thegrove_1",
        "participants": ["recep.thegrove"],
        // "imageColor": "white",
        "imageSize": 16
      });
    </script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/functions.js"></script>
    <script src="js/jquery.json-2.4.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/jquery.validate.min.js"></script>
  </body>
</html>
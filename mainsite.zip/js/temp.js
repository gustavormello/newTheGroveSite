var = removeDisplayNone;
removeDisplayNone = function () {
  document.getElementsByClassName('teste')
};



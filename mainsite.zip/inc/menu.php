    <!-- Fixed navbar -->
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Abrir navegação</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="./index.php">THE GROVE</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="./index.php">Início</a></li>
            <li><a href="metodo.php">Método</a></li>
            <li id="prices"><a href="#">Preços</a></li>
            <li><a href="sobre.php">Sobre</a></li>
            <li><a href="contato.php">Contato</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Promoções <b class="caret"></b></a>
              <ul class="dropdown-menu">
<!--                 <li><a href="skype.php">Inglês Presencial</a></li> -->
                <li><a href="<?php echo "$promo"; ?>">Inglês por Skype</a></li>
<!--                 <li><a href="empresas.php">Empresas</a></li>
                <li><a href="associacoes.php">Associações</a></li> -->
              </ul>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Autenticar-se <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="http://thegrove.com.br/metodo/index.php?title=Special:UserLogin">Aluno</a></li>
<!--                 <li><a href="login.php?type=empresa">Empresa</a></li>
<li><a href="login.php?type=associacao">Associação</a></li>
<li><a href="login.php?type=afiliado">Afiliado</a></li> -->
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>